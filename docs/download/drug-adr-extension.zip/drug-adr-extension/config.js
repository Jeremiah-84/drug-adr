window.ADR_CONFIG={"mode": "ext", "remote": "https://jeremiah-84.github.io/drug-adr/"};
